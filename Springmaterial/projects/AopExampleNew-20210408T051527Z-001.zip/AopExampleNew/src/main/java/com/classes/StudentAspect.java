package com.classes;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;



@Aspect
public class StudentAspect {
	@Before("execution(public String getName())")
	public void getNameAdvice(){
		System.out.println("Executing Advice on getName()");//2
	}
	
	/*@Before("execution(* com.classes.*.get*())")
	public void getAllAdvice(){
		System.out.println("Service method getter called");//1
	}
	
	@After("execution(public void set*(*))")
	public void setNameAdvice(){
		System.out.println("Executing Advice on set***()");//2
	}*/
	
	@AfterThrowing("execution(public void test())")
	public void getThrowAdvice()
	{
		System.out.println("Executing advice on throwing exception..");
	}
	
	@AfterReturning("execution(public String getName())")
	public void getReturnAdvice()
	{
		System.out.println("Executing advice on Returning exception..");
	}
}
